# Add this import at the top of render.py
from ..utils.marker_detection import get_marker_frame_range, get_all_camera_marker_ranges

# Update the apply_camera_settings method in RenderCleanupManager class
@classmethod
def apply_camera_settings(cls, context, cam_obj):
    """Apply camera settings to render"""
    from ..utils.callbacks import get_clean_camera_name
    
    settings = cam_obj.data.cameraide_settings
    cls._current_camera = cam_obj
    
    # Determine frame range based on timeline mode
    if settings.timeline_mode == 'MARKERS':
        marker_range = get_marker_frame_range(context.scene, cam_obj)
        if marker_range:
            frame_start, frame_end = marker_range
        else:
            # Fallback to custom if no markers found
            frame_start = settings.frame_start
            frame_end = settings.frame_end
    else:
        # Use custom frame range
        frame_start = settings.frame_start
        frame_end = settings.frame_end
    
    # Calculate resolution based on format
    res_x = settings.resolution_x
    res_y = settings.resolution_y
    percentage = settings.resolution_percentage
    
    # Adjust resolution for video formats, including scaling
    if settings.output_format in {'MP4', 'MKV', 'MOV'}:
        scaled_x = int((res_x * percentage) / 100)
        scaled_y = int((res_y * percentage) / 100)
        res_x = scaled_x + (scaled_x % 2)
        res_y = scaled_y + (scaled_y % 2)
        context.scene.render.resolution_percentage = 100
    else:
        context.scene.render.resolution_percentage = percentage
        
    # Apply frame range
    context.scene.frame_start = frame_start
    context.scene.frame_end = frame_end
    context.scene.frame_step = settings.frame_step
    context.scene.render.resolution_x = res_x
    context.scene.render.resolution_y = res_y
    context.scene.render.film_transparent = settings.film_transparent
    context.scene.render.use_stamp = settings.burn_metadata

    # Construct full output path
    base_path = bpy.path.abspath(settings.output_path)
    subfolder = settings.output_subfolder
    if settings.include_camera_name:
        clean_name = get_clean_camera_name(cam_obj)
        filename = f"{clean_name}_{settings.output_filename}"
    else:
        filename = settings.output_filename
        
    filepath = os.path.join(base_path, subfolder, filename)
    context.scene.render.filepath = filepath
    
    # Format settings
    if settings.output_format in {'PNG', 'JPEG', 'OPEN_EXR'}:
        context.scene.render.image_settings.file_format = settings.output_format
        cls._apply_format_settings(context, settings)
    else:
        context.scene.render.image_settings.file_format = 'FFMPEG'
        cls._apply_video_settings(context, settings)


# Update CAMERA_OT_render_all_viewport.execute() method
def execute(self, context):
    print("\n=== Starting Viewport Render Operation ===")
    
    # Get cameras based on timeline mode
    befriended_cameras = [obj for obj in context.scene.objects 
                   if obj.type == 'CAMERA' 
                   and obj.data.cameraide_settings.use_custom_settings]
    
    if not befriended_cameras:
        self.report({'WARNING'}, "No cameras with settings enabled")
        return {'CANCELLED'}
    
    # Check if any camera is in marker mode
    marker_mode_cameras = [cam for cam in befriended_cameras 
                          if cam.data.cameraide_settings.timeline_mode == 'MARKERS']
    
    if marker_mode_cameras:
        # Use timeline order from markers
        from ..utils.marker_detection import get_all_camera_marker_ranges
        marker_ranges = get_all_camera_marker_ranges(context.scene)
        
        # Filter to only befriended cameras
        befriended_set = set(befriended_cameras)
        self.cameras = [cam for cam, _, _, _ in marker_ranges if cam in befriended_set]
        
        # Add any custom-mode cameras not in markers
        custom_cameras = [cam for cam in befriended_cameras 
                         if cam.data.cameraide_settings.timeline_mode == 'CUSTOM' 
                         and cam not in self.cameras]
        self.cameras.extend(custom_cameras)
    else:
        # All cameras in custom mode - use original order
        self.cameras = befriended_cameras
    
    if not self.cameras:
        self.report({'WARNING'}, "No cameras to render")
        return {'CANCELLED'}
    
    # Reset all operator properties
    self.__class__.reset_flags()
    
    # Add fresh frame change handler
    if self.__class__.frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(self.__class__.frame_change)
    
    # Start timer and modal
    wm = context.window_manager
    self._timer = wm.event_timer_add(0.5, window=context.window)
    wm.modal_handler_add(self)
    
    return {'RUNNING_MODAL'}


# Update CAMERA_OT_render_all_normal.execute() method  
def execute(self, context):
    try:
        # Get all befriended cameras
        befriended_cameras = [obj for obj in context.scene.objects 
                      if obj.type == 'CAMERA' 
                      and obj.data.cameraide_settings.use_custom_settings]
        
        if not befriended_cameras:
            self.report({'WARNING'}, "No cameras with Cameraide settings enabled")
            return {'CANCELLED'}
        
        # Check if any camera is in marker mode
        marker_mode_cameras = [cam for cam in befriended_cameras 
                              if cam.data.cameraide_settings.timeline_mode == 'MARKERS']
        
        if marker_mode_cameras:
            # Use timeline order from markers
            from ..utils.marker_detection import get_all_camera_marker_ranges
            marker_ranges = get_all_camera_marker_ranges(context.scene)
            
            # Filter to only befriended cameras
            befriended_set = set(befriended_cameras)
            self.cameras = [cam for cam, _, _, _ in marker_ranges if cam in befriended_set]
            
            # Add any custom-mode cameras not in markers
            custom_cameras = [cam for cam in befriended_cameras 
                             if cam.data.cameraide_settings.timeline_mode == 'CUSTOM' 
                             and cam not in self.cameras]
            self.cameras.extend(custom_cameras)
        else:
            # All cameras in custom mode
            self.cameras = befriended_cameras
        
        if not self.cameras:
            self.report({'WARNING'}, "No cameras to render")
            return {'CANCELLED'}
        
        print(f"\nFound {len(self.cameras)} cameras to render")
        
        self.current_index = -1
        self.is_rendering = False
        self._last_frame = None
        
        # Add timer for modal
        wm = context.window_manager
        self._timer = wm.event_timer_add(3, window=context.window)
        wm.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}
        
    except Exception as e:
        self.report({'ERROR'}, f"Failed to start batch render: {str(e)}")
        print(f"Error: {str(e)}")
        return {'CANCELLED'}
