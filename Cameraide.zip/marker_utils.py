import bpy

def get_camera_markers(scene):
    """Get all timeline markers that have cameras assigned"""
    camera_markers = []
    for marker in scene.timeline_markers:
        if marker.camera:
            camera_markers.append(marker)
    return camera_markers

def get_marker_for_camera(scene, camera_obj):
    """Find markers that reference the given camera"""
    markers = []
    for marker in scene.timeline_markers:
        if marker.camera == camera_obj:
            markers.append(marker)
    return markers

def get_marker_frame_range(scene, camera_obj):
    """
    Get the frame range for a camera from timeline markers.
    Returns (start_frame, end_frame) or None if no markers found.
    
    If multiple markers exist for the same camera, returns the span
    from the earliest start to the latest end.
    """
    markers = get_marker_for_camera(scene, camera_obj)
    if not markers:
        return None
    
    # Sort markers by frame
    sorted_markers = sorted(markers, key=lambda m: m.frame)
    
    # Find the range for this camera
    start_frame = sorted_markers[0].frame
    
    # Find end frame - look for next marker or end of timeline
    all_markers = sorted(scene.timeline_markers, key=lambda m: m.frame)
    
    end_frame = scene.frame_end
    for i, marker in enumerate(all_markers):
        if marker == sorted_markers[-1]:  # Last marker for this camera
            # Check if there's a next marker
            if i + 1 < len(all_markers):
                end_frame = all_markers[i + 1].frame - 1
            break
    
    return (start_frame, end_frame)

def get_all_camera_marker_ranges(scene):
    """
    Get all cameras with markers and their frame ranges.
    Returns list of tuples: [(camera_obj, start_frame, end_frame, marker_name), ...]
    Sorted by timeline order.
    """
    camera_ranges = []
    seen_cameras = set()
    
    sorted_markers = sorted(scene.timeline_markers, key=lambda m: m.frame)
    
    for i, marker in enumerate(sorted_markers):
        if not marker.camera or marker.camera in seen_cameras:
            continue
        
        start = marker.frame
        # Find end frame (next marker or scene end)
        if i + 1 < len(sorted_markers):
            end = sorted_markers[i + 1].frame - 1
        else:
            end = scene.frame_end
        
        camera_ranges.append((marker.camera, start, end, marker.name))
        seen_cameras.add(marker.camera)
    
    return camera_ranges

def has_camera_markers(scene):
    """Quick check if scene has any camera markers"""
    return any(marker.camera for marker in scene.timeline_markers)

def count_camera_markers(scene):
    """Count unique cameras in timeline markers"""
    cameras = set()
    for marker in scene.timeline_markers:
        if marker.camera:
            cameras.add(marker.camera)
    return len(cameras)
