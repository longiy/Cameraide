import bpy
from bpy.types import Panel
from ..utils.marker_detection import (
    has_camera_markers, 
    count_camera_markers, 
    get_marker_frame_range
)

class CAMERAIDE_PT_sidebar_panel(Panel):
    bl_label = "Cameraide 1.0.7"
    bl_idname = "CAMERAIDE_PT_sidebar_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Camera"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        layout = self.layout

        if context.active_object and context.active_object.type == 'CAMERA':
            cam_obj = context.active_object
            cam = cam_obj.data
            camera_name = cam_obj.name
        elif context.scene.camera:
            cam_obj = context.scene.camera
            cam = cam_obj.data
            camera_name = cam_obj.name
        else:
            layout.label(text="No active camera in the scene")
            return

        settings = cam.cameraide_settings

        # Friend/Befriend button
        row = layout.row()
        row.scale_y = 2.0
        if settings.use_custom_settings:
            row.operator("camera.toggle_custom_settings", text=f"{camera_name}", icon='FUND', depress=True)
        else:
            row.operator("camera.toggle_custom_settings", text=f"{camera_name}", icon='DECORATE')

        if settings.use_custom_settings:
            # Timeline Control Mode Selector
            box = layout.box()
            box.label(text="Timeline Control", icon='TIME')
            
            col = box.column(align=True)
            
            # Check for markers
            has_markers = has_camera_markers(context.scene)
            marker_count = count_camera_markers(context.scene)
            marker_range = get_marker_frame_range(context.scene, cam_obj)
            
            # Markers mode
            row = col.row(align=True)
            row.enabled = has_markers
            row.prop(settings, "timeline_mode", expand=False, text="")
            
            # Info row
            if settings.timeline_mode == 'MARKERS':
                if marker_range:
                    info_row = col.row()
                    info_row.label(text=f"Marker Range: {marker_range[0]} - {marker_range[1]}", icon='MARKER_HLT')
                elif has_markers:
                    info_row = col.row()
                    info_row.alert = True
                    info_row.label(text="No marker for this camera", icon='ERROR')
                else:
                    info_row = col.row()
                    info_row.alert = True
                    info_row.label(text="No camera markers in scene", icon='INFO')
            else:
                if has_markers:
                    info_row = col.row()
                    info_row.label(text=f"Detected: {marker_count} camera markers", icon='INFO')
            
            layout.separator(factor=0.5)

            # Resolution
            box = layout.box()
            row = box.row(align=True)
            row.prop(settings, "show_resolution_settings", 
                text="Resolution", 
                icon='TRIA_DOWN' if settings.show_resolution_settings else 'TRIA_RIGHT',
                emboss=False
            )
            
            if settings.show_resolution_settings:
                col = box.column(align=True)
                
                row = col.row(align=True)
                split = row.split(factor=0.43, align=True)
                split.prop(settings, "resolution_x")
                
                subsplit = split.split(factor=0.16, align=True)
                subsplit.operator("camera.swap_resolution", text="", icon='ARROW_LEFTRIGHT')
                subsplit.prop(settings, "resolution_y")
                
                col.prop(settings, "resolution_percentage", slider=True)
                row = col.row(align=True)
                row.menu("CAMERA_MT_resolution_presets_menu", text="Presets")

            # Frame Range
            box = layout.box()
            row = box.row(align=True)
            
            # Add mode indicator icon
            if settings.timeline_mode == 'MARKERS':
                row.label(text="", icon='MARKER_HLT')
            
            row.prop(settings, "show_frame_range", 
                text="Frame Range", 
                icon='TRIA_DOWN' if settings.show_frame_range else 'TRIA_RIGHT',
                emboss=False
            )
            
            if settings.show_frame_range:
                col = box.column(align=True)
                
                # If in marker mode, show read-only info
                if settings.timeline_mode == 'MARKERS':
                    if marker_range:
                        row = col.row(align=True)
                        row.enabled = False
                        row.prop(settings, "frame_start", text="Start")
                        row.prop(settings, "frame_end", text="End")
                        
                        # Update the property values to match markers (read-only display)
                        settings.frame_start = marker_range[0]
                        settings.frame_end = marker_range[1]
                        
                        info = col.row()
                        info.label(text="(Controlled by timeline markers)", icon='INFO')
                    else:
                        row = col.row()
                        row.alert = True
                        row.label(text="No markers found for this camera", icon='ERROR')
                        row = col.row()
                        row.label(text="Switch to Custom mode or add markers")
                else:
                    # Custom mode - normal editable controls
                    row = col.row(align=True)
                    row.prop(settings, "frame_start")
                    row.prop(settings, "frame_end")
                    col.prop(settings, "frame_step")
                    col.operator("camera.toggle_frame_range_sync", 
                        text="Sync " + ("ON" if settings.sync_frame_range else "OFF"), 
                        icon='PREVIEW_RANGE',
                        depress=settings.sync_frame_range)

            # File Output
            box = layout.box()
            row = box.row(align=True)
            row.prop(settings, "show_file_output", 
                text="File Output", 
                icon='TRIA_DOWN' if settings.show_file_output else 'TRIA_RIGHT',
                emboss=False
            )
            
            if settings.show_file_output:
                col = box.column(align=True)
                col.prop(settings, "output_path", text="")
                col.prop(settings, "output_subfolder", text="")
                col.prop(settings, "output_filename", text="")

            # Format Settings
            box = layout.box()
            row = box.row(align=True)
            row.prop(settings, "show_format_settings", 
                text="File Format", 
                icon='TRIA_DOWN' if settings.show_format_settings else 'TRIA_RIGHT',
                emboss=False
            )
            
            if settings.show_format_settings:
                col = box.column(align=True)
                
                row = col.row(align=True)
                row.prop_enum(settings, "output_format", 'PNG', text="PNG")
                row.prop_enum(settings, "output_format", 'JPEG', text="JPEG")
                row.prop_enum(settings, "output_format", 'OPEN_EXR', text="EXR")

                row = col.row(align=True)
                row.prop_enum(settings, "output_format", 'MP4', text="MP4")
                row.prop_enum(settings, "output_format", 'MKV', text="MKV")
                row.prop_enum(settings, "output_format", 'MOV', text="MOV")
                col.separator(factor=0.5)

                if settings.output_format == 'PNG':
                    row = col.row(align=True)
                    row.prop(settings, "png_color_depth", text="")
                    row.prop(settings, "png_compression", slider=True)
                    
                elif settings.output_format == 'JPEG':
                    col.prop(settings, "jpeg_quality", slider=True)
                    
                elif settings.output_format == 'OPEN_EXR':
                    row = col.row(align=True)
                    row.prop(settings, "exr_color_depth", text="")
                    row.prop(settings, "exr_codec", text="")

                if settings.output_format in {'MP4', 'MKV', 'MOV'}:
                    row = col.row(align=True)
                    col.prop(settings, "use_audio", text="Audio (mp3)")

            # Extra Settings
            box = layout.box()
            row = box.row(align=True)
            row.prop(settings, "show_extra_settings", 
                text="Extra Settings", 
                icon='TRIA_DOWN' if settings.show_extra_settings else 'TRIA_RIGHT',
                emboss=False
            )
            
            if settings.show_extra_settings:
                col = box.column(align=True)
                if settings.output_format in {'PNG', 'JPEG', 'OPEN_EXR'}:
                    col.prop(settings, "overwrite_existing")
                if settings.output_format in {'PNG', 'OPEN_EXR'}:
                    col.prop(settings, "film_transparent")
                col.prop(settings, "include_camera_name")
                col.prop(settings, "burn_metadata")

            # Render Buttons
            row = layout.row(align=True)
            split = row.split(factor=0.85, align=True)
            split.scale_y = 1.5
            split.operator("camera.render_selected_viewport", text="Render Viewport", icon="RESTRICT_VIEW_OFF")
            split.alert = True
            split.operator("camera.render_all_viewport", text="All")
            
            row = layout.row(align=True)
            split = row.split(factor=0.85, align=True)
            split.scale_y = 1.5
            split.operator("camera.render_selected_normal", text="Render Normal", icon="RESTRICT_RENDER_OFF")
            split.alert = True
            split.operator("camera.render_all_normal", text="All")
    
def register():
    try:
        bpy.utils.unregister_class(CAMERAIDE_PT_sidebar_panel)
    except:
        pass
    bpy.utils.register_class(CAMERAIDE_PT_sidebar_panel)

def unregister():
    try:
        bpy.utils.unregister_class(CAMERAIDE_PT_sidebar_panel)
    except:
        pass
